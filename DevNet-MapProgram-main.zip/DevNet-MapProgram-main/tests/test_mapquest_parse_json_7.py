import unittest
from unittest.mock import patch
import mapquest_parse_json_7  # Import the actual script to test

class TestMapQuestParseJson(unittest.TestCase):
    
    # Test for fetching directions
    @patch('mapquest_parse_json_7.requests.get')
    def test_fetch_directions(self, mock_get):
        # Sample mock data for the directions API
        mock_data = {
            "info": {"statuscode": 0},
            "route": {
                "formattedTime": "1 hour 20 mins",
                "distance": 200,  # in miles
                "fuelUsed": 5,  # in gallons
                "legs": [{
                    "maneuvers": [
                        {"narrative": "Turn left", "distance": 1}
                    ]
                }]
            }
        }
        # Set up the mock to return the sample data
        mock_get.return_value.json.return_value = mock_data

        # Call the function you want to test
        with patch('builtins.input', side_effect=["New York", "Boston"]):  # Mocking user inputs
            with patch('builtins.print') as mock_print:
                # This would run the code as if the user enters "New York" and "Boston"
                mapquest_parse_json_7.main()  # Assuming you have a main() function

        # Check that print statements contain expected values
        mock_print.assert_any_call("Directions from New York to Boston")
        mock_print.assert_any_call("Trip Duration:   1 hour 20 mins")
        mock_print.assert_any_call("Kilometers:      322.00")  # Converted from miles to km (200 * 1.61)
        mock_print.assert_any_call("Fuel Used (Ltr) (API): 18.90")  # Converted from gallons to liters (5 * 3.78)
        
    # Test for handling errors in directions API
    @patch('mapquest_parse_json_7.requests.get')
    def test_fetch_directions_error(self, mock_get):
        # Mocking an error response (invalid status code)
        mock_data = {
            "info": {"statuscode": 402},  # Invalid status code
        }
        mock_get.return_value.json.return_value = mock_data

        # Call the function with invalid inputs
        with patch('builtins.input', side_effect=["Invalid Location", "Another Invalid Location"]):
            with patch('builtins.print') as mock_print:
                mapquest_parse_json_7.main()  # Assuming you have a main() function

        # Check that an error message is printed
        mock_print.assert_any_call("**********************************************")
        mock_print.assert_any_call("Status Code: 402; Invalid user inputs for one or both locations.")
        mock_print.assert_any_call("**********************************************")

    # Test for fetching parking data
    @patch('mapquest_parse_json_7.requests.get')
    def test_fetch_parking_data(self, mock_get):
        # Sample mock data for parking API
        mock_data = {
            "info": {"statuscode": 0},
            "searchResults": [
                {"name": "Parking Lot A", "fields": {"address": "123 Main St"}},
                {"name": "Parking Lot B", "fields": {"address": "456 Elm St"}}
            ]
        }
        # Set up the mock to return the sample data
        mock_get.return_value.json.return_value = mock_data

        # Mock user input and print output
        with patch('builtins.input', side_effect=["New York", "Boston"]):
            with patch('builtins.print') as mock_print:
                mapquest_parse_json_7.main()  # Assuming you have a main() function

        # Check that parking locations are printed
        mock_print.assert_any_call("Nearby Parking Locations (within 10 miles):")
        mock_print.assert_any_call("- Parking Lot A at 123 Main St")
        mock_print.assert_any_call("- Parking Lot B at 456 Elm St")

    # Test for fetching weather data
    @patch('mapquest_parse_json_7.requests.get')
    def test_fetch_weather_data(self, mock_get):
        # Sample mock data for the weather API
        mock_data = {
            "cod": 200,
            "main": {"temp": 25, "humidity": 50},
            "weather": [{"description": "clear sky"}]
        }
        # Set up the mock to return the sample data
        mock_get.return_value.json.return_value = mock_data

        # Mock user input and print output
        with patch('builtins.input', side_effect=["New York", "Boston"]):
            with patch('builtins.print') as mock_print:
                mapquest_parse_json_7.main()  # Assuming you have a main() function

        # Check that weather data is printed
        mock_print.assert_any_call("Weather Information:")
        mock_print.assert_any_call("Temperature: 25°C")
        mock_print.assert_any_call("Weather: clear sky")
        mock_print.assert_any_call("Humidity: 50%")

    # Test for fetching traffic incidents
    @patch('mapquest_parse_json_7.requests.get')
    def test_fetch_traffic_incidents(self, mock_get):
        # Sample mock data for traffic API
        mock_data = {
            "incidents": [
                {"shortDesc": "Accident on I-95"},
                {"shortDesc": "Traffic jam on Main St"}
            ]
        }
        # Set up the mock to return the sample data
        mock_get.return_value.json.return_value = mock_data

        # Mock user input and print output
        with patch('builtins.input', side_effect=["New York", "Boston"]):
            with patch('builtins.print') as mock_print:
                mapquest_parse_json_7.main()  # Assuming you have a main() function

        # Check that traffic incidents are printed
        mock_print.assert_any_call("Live Traffic Incidents:")
        mock_print.assert_any_call("- Accident on I-95")
        mock_print.assert_any_call("- Traffic jam on Main St")

if __name__ == '__main__':
    unittest.main()
