import urllib.parse
import requests

# MapQuest API Key
mapquest_key = "nTUjV9WBMsnnkzaHxORpBfx9roxPyUT8"
# OpenWeatherMap API Key
weather_key = "00aa962b617487046429dfb75634f4f8"

# MapQuest API Endpoints
main_api = "https://www.mapquestapi.com/directions/v2/route?"
parking_api = "https://www.mapquestapi.com/search/v2/radius?"
traffic_api = "https://www.mapquestapi.com/traffic/v2/incidents?"

# OpenWeatherMap API Endpoint
weather_api = "https://api.openweathermap.org/data/2.5/weather"

# Default fuel efficiency (liters per 100 km)
fuel_efficiency = 8.5  # Adjust this based on your vehicle

while True:
    orig = input("Starting Location: ")
    if orig.lower() in ["quit", "q"]:
        break

    dest = input("Destination: ")
    if dest.lower() in ["quit", "q"]:
        break

    # Fetch Directions
    url = main_api + urllib.parse.urlencode({"key": mapquest_key, "from": orig, "to": dest})
    json_data = requests.get(url).json()

    print("URL: " + url)
    json_status = json_data["info"]["statuscode"]

    if json_status == 0:
        print("\n=============================================")
        print(f"Directions from {orig} to {dest}")
        print(f"Trip Duration:   {json_data['route']['formattedTime']}")
        distance_km = json_data["route"]["distance"] * 1.61
        print(f"Kilometers:      {distance_km:.2f}")
        
        
        
        # Check for the 'fuelUsed' key
        if "fuelUsed" in json_data["route"]:
            fuel_used_api = json_data["route"]["fuelUsed"] * 3.78  # Convert gallons to liters
            print(f"Fuel Used (Ltr) (API): {fuel_used_api:.2f}")
        else:
            # Fallback calculation based on distance and fuel efficiency
            fuel_used_calc = (distance_km * fuel_efficiency) / 100
            print(f"Fuel Used (Ltr) (Calculated): {fuel_used_calc:.2f}")
        print("=============================================")

        for each in json_data["route"]["legs"][0]["maneuvers"]:
            print((each["narrative"]) + " (" + str("{:.2f}".format((each["distance"]) * 1.61) + " km)"))

        print("=============================================\n")
        
        
        

        # Fetch Parking Data
        lat_lng = json_data["route"]["boundingBox"]["ul"]
        parking_url = parking_api + urllib.parse.urlencode({
            "key": mapquest_key,
            "origin": f"{lat_lng['lat']},{lat_lng['lng']}",
            "radius": 10,
            "maxMatches": 5,
            "hostedData": "mqap.ntpois|group_sic_code=?|7520"
        })
        parking_data = requests.get(parking_url).json()
        print("\nNearby Parking Locations (within 10 miles):")

        # Handle potential missing keys in parking data response
        if parking_data.get("info") and parking_data["info"].get("statuscode") == 0:
            if parking_data.get("searchResults"):
                for parking in parking_data["searchResults"]:
                    print(f"- {parking['name']} at {parking['fields']['address']}")
            else:
                print("No parking data available.")
        else:
            print("Parking data unavailable or malformed.")

        # Fetch Weather Data
        weather_url = weather_api + urllib.parse.urlencode({
            "lat": lat_lng["lat"],
            "lon": lat_lng["lng"],
            "appid": weather_key,
            "units": "metric"
        })
        weather_data = requests.get(weather_url).json()
        print("\nWeather Information:")
        if weather_data.get("cod") == 200:
            print(f"Temperature: {weather_data['main']['temp']}°C")
            print(f"Weather: {weather_data['weather'][0]['description']}")
            print(f"Humidity: {weather_data['main']['humidity']}%")
        else:
            print("Weather information not available.")

        # Fetch Traffic Incidents
        bounding_box = json_data["route"]["boundingBox"]
        traffic_url = traffic_api + urllib.parse.urlencode({
            "key": mapquest_key,
            "boundingBox": f"{bounding_box['ul']['lat']},{bounding_box['ul']['lng']},{bounding_box['lr']['lat']},{bounding_box['lr']['lng']}"
        })
        traffic_data = requests.get(traffic_url).json()
        print("\nLive Traffic Incidents:")
        if traffic_data.get("incidents"):
            for incident in traffic_data["incidents"]:
                print(f"- {incident['shortDesc']}")
        else:
            print("No traffic incidents reported.")

    elif json_status == 402:
        print("**********************************************")
        print("Status Code: 402; Invalid user inputs for one or both locations.")
        print("**********************************************\n")
    elif json_status == 611:
        print("**********************************************")
        print("Status Code: 611; Missing an entry for one or both locations.")
        print("**********************************************\n")
    else:
        print("************************************************************************")
        print(f"For Status Code: {json_status}; Refer to:")
        print("https://developer.mapquest.com/documentation/directions-api/status-codes")
        print("************************************************************************\n")
